# crawlsl.py
# Written by Hanna Jeon (전한나)

# crawlsl.py는 셀레니움 응용 크롤러다. 
# 셀레니움이 필요한 뉴스 사이트가 없어 현재 함수가 없는 상황. (미완성)

# SPDX-FileCopyrightText: © 2021 Hanna Jeon <jhn90928@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

def crawl_allsl(link, press, reporter):
    pressname = None
    reportername = None
    articletitle = None
    articlecontent = None
    return pressname, reportername, articletitle, articlecontent